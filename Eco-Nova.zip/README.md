# example-app-router

An example that showcases basic usage of `next-intl` with the App Router, including internationalized routing.

[Demo](https://next-intl-example-app-router.vercel.app/)

## Deploy your own

By deploying to [Vercel](https://vercel.com), you can check out the example in action. Note that you'll be prompted to create a new GitHub repository as part of this, allowing you to make subsequent changes.

[![Deploy with Vercel](https://vercel.com/button)](https://vercel.com/new/clone?repository-url=https://github.com/amannn/next-intl/tree/main/examples/example-app-router)
